import { NetworkDiagramAndSliders } from './NetworkDiagramAndSliders';

export const NetworkDiagramAvailableForcesDemo = ({
  width = 700,
  height = 400,
}) => {
  return <NetworkDiagramAndSliders width={width} height={height} />;
};
